import flask
from flask_cors import CORS
from google.cloud import vision
import sqlalchemy


app = flask.Flask(__name__)
CORS(app)

connection_name = "gcp-university-project:us-central1:sql-db-tf-2"
driver_name = 'postgres+pg8000'
db_name = "db-tf"
db_user = "root"
db_password = "pass!123"
table_name = "students_group"
query_string =  dict({"unix_sock": "/cloudsql/{}/.s.PGSQL.5432".format(connection_name)})
    
db = sqlalchemy.create_engine(
    sqlalchemy.engine.url.URL(
    drivername=driver_name,
    username=db_user,
    password=db_password,
    database=db_name,
    query=query_string,
    ),
    pool_size=5,
    max_overflow=2,
    pool_timeout=30,
    pool_recycle=1800
)

# --------------------------------------------------------------------------------------------------------------------
def getNrAlbumu(multilineText):
    subMatchStr = "Nr albumu: "
    for line in multilineText.splitlines():
        if subMatchStr in line:
            return line[len(subMatchStr):len(subMatchStr)+10]
# --------------------------------------------------------------------------------------------------------------------
def signup(student_no):
    # stmt = sqlalchemy.text('insert into {} ({}) values ({})'.format(table_name, table_field, table_field_value))
    query_str = "INSERT INTO students_group (student_id_no) values ('" + student_no + "');"
    stmt = sqlalchemy.text(query_str)
    
    try:
        with db.connect() as conn:
            conn.execute(stmt)
    except Exception as e:
        return 'Error: {}'.format(str(e))
    return 'ok'      
# --------------------------------------------------------------------------------------------------------------------
def resign(student_no):
    query_str = "DELETE FROM students_group WHERE student_id_no ='" + student_no + "';"
    stmt = sqlalchemy.text(query_str)
    
    try:
        with db.connect() as conn:
            conn.execute(stmt)
    except Exception as e:
        return 'Error: {}'.format(str(e))
    return 'ok'     
# --------------------------------------------------------------------------------------------------------------------
def checkIfStudentExistInDbByIdNo(student_no):
    query_str = "SELECT id from students_group WHERE student_id_no ='" + student_no + "';"
    stmt = sqlalchemy.text(query_str)
    try:
        with db.connect() as conn:
            results =conn.execute(stmt)
            records = [dict(zip(row.keys(), row)) for row in results]
            if len(records) == 0:
                return False
            else:
                return True
    except Exception as e:
        return 'Error: {}'.format(str(e))   

@app.route("/")
def update_student_membership(request):

    ## Set CORS headers for the preflight request
    if request.method == 'OPTIONS':
        ## Allows GET requests from any origin with the Content-Type
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': ['POST','OPTIONS'],
            'Access-Control-Allow-Headers': 'Content-Type',
        }

        return ('', 204, headers)

    ## Set CORS headers for the main request
    headers = {
        'Access-Control-Allow-Origin': '*'
    }


    if not request.files:
        return ("Invalid arguments", 400, headers)
    if not request.files["image"]:
        return ("Scan of student card required!", 400, headers)
    if not request.form["option"] and not (request.form["option"] == "signup" or request.form["option"] == "resign"):
            return ("Signup / resign option must be selected.", 400, headers)
    try:
        image_to_analyze = request.files["image"].read()
        chosen_option = request.form["option"]

        client = vision.ImageAnnotatorClient()
        image = vision.Image(content=image_to_analyze)
        response = client.text_detection(image=image)

        if response.error.message:
            return ("Vision API error", 400, headers)

        texts = response.text_annotations
        detected_text = ""
        for text in texts:
            detected_text += text.description
        resp_data = getNrAlbumu(detected_text)
        if resp_data is None or not resp_data.isnumeric() or len(resp_data) != 10:
            return ("Could not properly scan student identification no.", 400, headers)
        if chosen_option == "signup":
            db_resp = signup(resp_data)
            if db_resp == "ok":
                return ("You've been signed up as a member of the group", 200, headers)
            else:
                if "duplicate key value" in db_resp:
                    return ("Student with that student identification no. already is a member of the group", 400, headers)
                if 'violates check constraint "id_no_len"' in db_resp:
                    return ("Invalid student identification no.", 400, headers)
                return ("Error during saving data to database", 400, headers)
        else:
            isStudentMember = checkIfStudentExistInDbByIdNo(resp_data)
            if not isStudentMember:
                return ("Cannot resign, because you are not a member of this research group.", 400, headers)
            db_resp = resign(resp_data)
            if db_resp == "ok":
                return ("You've been removed from the members list", 200, headers)
            else:
                 return (db_resp, 400, headers)

    except:
        return ("Something went wrong! Could not handle request.", 400, headers)

